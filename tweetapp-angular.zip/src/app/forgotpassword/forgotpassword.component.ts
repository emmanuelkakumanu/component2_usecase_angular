import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../services/user';
import { UserAuthService } from '../services/user-auth.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  authSource: string;
  error: string;
  isValid: boolean;
  status: boolean;
  user: User;
  constructor(private fb: FormBuilder, private router: Router, private userService: UserService, private userAuthService: UserAuthService) { }

  ngOnInit(): void {
    this.forgotPasswordForm = this.fb.group({
      userName: ['', [Validators.required, Validators.minLength(4),
      Validators.maxLength(20), Validators.pattern('^[a-zA-Z0-9]*')]],
      emailId: ['', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]],
      password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]],
      confirmPassword: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]]
    },
    );

  }

  onUpdatePassword() {
    this.userService.updatePassword(this.forgotPasswordForm.value.userName, this.forgotPasswordForm.value.emailId, this.forgotPasswordForm.value.password).subscribe(
      (response) => {
        this.status = response;
        if (response == true) {
          this.router.navigate(['/login']);
        }
        else {
          this.isValid = true;
        }


      })

  }

}
