import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { Tweet } from '../services/tweet';
import { TweetService } from '../services/tweet.service';
import { UserAuthService } from '../services/user-auth.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  tweets: Tweet[];
  click: boolean = false;
  loggInUserTweets: Tweet[];


  constructor(private tweetService: TweetService, private userAuthService: UserAuthService, private authenticationService: AuthenticationService) { }
  ngOnInit(): void {
    this.tweetService.getAllTweets().subscribe(data => {
      this.tweets = data;
    })

    this.tweetService.getAllUserTweets().subscribe(data => {
      this.loggInUserTweets = data;
    })
  }
  postTweet(getTweet: string) {
    this.tweetService.postTweet(getTweet).subscribe(response => {
      this.ngOnInit();
    });
  }
  isAuthenticated() {
    return this.userAuthService.loggedIn;
  }
  getLoginId() {
    return this.userAuthService.getLoginid();
  }
  likeButtonClick(likedTweet: Tweet) {
    likedTweet.likeCount = likedTweet.likeCount + 1;
    this.tweetService.likeTweet(likedTweet).subscribe(response => {
      this.click = true;
    });
  }

  deleteButtonClick(deleteTweet: Tweet) {
    this.tweetService.deleteTweet(deleteTweet).subscribe(response => {
      this.ngOnInit();
    });
  }

}
