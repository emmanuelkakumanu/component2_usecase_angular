export interface UserDTO {
    confirmPassword: string;
    contactNo: string;
    emailId: string;
    firstName: string;
    lastName: string;
    password: string;
    userName: string;
}