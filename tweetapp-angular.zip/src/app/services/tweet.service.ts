import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Tweet } from './tweet';
import { UserAuthService } from './user-auth.service';

@Injectable({
  providedIn: 'root'
})
export class TweetService {
  tweetApiUrl = "http://localhost:8092/api/v1.0/tweets";
  sendTweet: Tweet;
  constructor(private httpClient: HttpClient, private userAuthService: UserAuthService) { }

  getAllTweets() {
    return this.httpClient.get<Tweet[]>(this.tweetApiUrl + "/all");
  }

  getAllUserTweets() {
    return this.httpClient.get<Tweet[]>(this.tweetApiUrl + "/" + this.userAuthService.getLoginid() + "/all");
  }

  likeTweet(likedTweet: Tweet) {
    console.log(likedTweet);
    return this.httpClient.put(this.tweetApiUrl + "/" + likedTweet.loginId + "/like/" + likedTweet.id, likedTweet);

  }

  deleteTweet(deleteTweet: Tweet) {
    return this.httpClient.delete(this.tweetApiUrl + "/" + deleteTweet.loginId + "/delete/" + deleteTweet.id);
  }

  postTweet(getTweet: string) {
    return this.httpClient.get(this.tweetApiUrl + "/" + this.userAuthService.getLoginid() + "/add/" + getTweet);
  }
}
