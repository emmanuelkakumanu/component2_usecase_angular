import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  authenticationApiUrl = 'http://localhost:8092/api/v1.0/tweets/login';
  private token: string;
  constructor(private httpClient: HttpClient) { }
  authenticate(user: string, password: string): Observable<any> {
    let credentials = btoa(user + ':' + password);
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Basic ' + credentials);
    return this.httpClient.get<User>(this.authenticationApiUrl, { headers }).pipe(
      map((successData: User) => {
        let Userdetails: User = successData;
        sessionStorage.setItem("token", credentials);
        sessionStorage.setItem("username", Userdetails.emailId);
        return successData;
      }),
      map(failureData => {
        return failureData;
      })
    );
  }
  getToken() {
    if (this.isUserLoggedIn())
      return sessionStorage.getItem("token");
    return null;
  }



  getUser(): string {
    let user = sessionStorage.getItem('user');
    return user;
  }

  public isUserLoggedIn(): boolean {
    let user = sessionStorage.getItem('userid');
    if (user == null)
      return false;
    return true;
  }
  logout() {
    sessionStorage.clear();
  }
}
