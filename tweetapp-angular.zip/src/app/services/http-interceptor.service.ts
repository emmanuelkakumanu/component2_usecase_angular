import { HttpRequest, HttpHandler } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthenticationService } from './authentication.service';
import { UserAuthService } from './user-auth.service';

@Injectable({
  providedIn: 'root'
})
export class HttpInterceptorService {

  constructor(public userAuthService: UserAuthService, private authenticationService: AuthenticationService) { }
  intercept(request: HttpRequest<any>, next: HttpHandler) {
    if (this.userAuthService.getToken()) {
      // request object cannot be directly manipulated 
      // it has to be cloned 
      let authenticationToken = this.authenticationService.getToken();
      request = request.clone({
        setHeaders: {
          Authorization: authenticationToken
        }
      });
    }

    // return back next step : continue to server

    return next.handle(request);
  }

}
