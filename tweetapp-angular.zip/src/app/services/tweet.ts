import { Timestamp } from "rxjs";

export interface Tweet {
    id: number;
    loginId: string;
    tweet: string;
    likeCount: number;
    postedOn: Date;
}