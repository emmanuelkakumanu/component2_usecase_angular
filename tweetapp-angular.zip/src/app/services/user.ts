export interface User {

    firstName: string;
    lastName: string;
    emailId: string;
    loginid: string;
    password?: string;
    contactNo: string;
}