import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserAuthService } from './user-auth.service';
import { UserDTO } from './userDTO';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userApiUrl = "http://localhost:8092/api/v1.0/tweets/register";
  constructor(private httpClient: HttpClient, private userAuthService: UserAuthService) { }

  addUser(userDTO: UserDTO) {
    return this.httpClient.post<UserDTO>(this.userApiUrl, userDTO);
  }

  updatePassword(loginid: string, email: string, password: string) {
    return this.httpClient.get<boolean>("http://localhost:8092/api/v1.0/tweets/" + loginid + "/" + email + "/" + password + "/forgot");

  }
}
