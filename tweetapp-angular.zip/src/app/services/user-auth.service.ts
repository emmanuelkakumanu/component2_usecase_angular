import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  constructor() { }

  redirectUrl = '/';
  loggedIn = false;
  token: string;
  user: string;
  loginid: string;

  public setLoginid(loginid: string) {
    this.loginid = loginid;
  }
  public getLoginid(): string {
    return this.loginid;
  }

  public setToken(token: string) {
    this.token = token;
  }
  public getToken() {
    return this.token;
  }
  public setUser(user: string) {
    this.user = user;
  }
  public getUser() {
    return this.user;
  }
  public logout() {
    this.redirectUrl = '/';
    this.user = null;
    this.loggedIn = false;
  }
}
