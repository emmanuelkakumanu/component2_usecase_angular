import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserAuthService } from './services/user-auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TweetApp';
  logged: boolean;
  status: boolean = true;
  constructor(private router: Router, private userAuthService: UserAuthService) { }
  isAuthenticated() {
    this.logged = true;
    return this.userAuthService.loggedIn;
  }
  user() {
    return this.userAuthService.getLoginid();
  }
  onSignOut() {
    this.userAuthService.logout();
    this.router.navigate(['/login']);
  }

}
