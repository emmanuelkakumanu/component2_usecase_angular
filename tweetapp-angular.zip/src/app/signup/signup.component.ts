import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../services/user';
import { UserAuthService } from '../services/user-auth.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm: FormGroup;
  authSource: string;
  error: string;
  exist: boolean;
  user: User;

  constructor(private fb: FormBuilder, private router: Router, private userService: UserService, private userAuthService: UserAuthService) { }

  ngOnInit(): void {

    this.signupForm = this.fb.group({
      userName: ['', [Validators.required, Validators.minLength(4),
      Validators.maxLength(20), Validators.pattern('^[a-zA-Z0-9]*')]],
      firstName: ['', [Validators.required, Validators.minLength(4),
      Validators.maxLength(20), Validators.pattern('^[a-zA-Z]*')]],
      lastName: ['', [Validators.required, Validators.minLength(4), Validators.maxLength(20), Validators.pattern('^[a-zA-Z]*')]],
      emailId: ['', [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]],
      contactNo: ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9+]*')]],
      password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]],
      confirmPassword: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]]
    },
    );

  }


  onSignup() {
    this.userService.addUser(this.signupForm.value).subscribe(
      (response) => {
        this.router.navigate(['/login']);
      },
      (responseError) => {
        this.exist = true;
        this.error = responseError.error.errorMessage;
      });

  }

  isExist() {
    return this.exist;
  }
  get userName() {
    return this.signupForm.get('userName');
  }
  get contactNo() {
    return this.signupForm.get('contactNo');
  }
  get emailId() {
    return this.signupForm.get('emailId');
  }
  get password() {
    return this.signupForm.get('password');
  }
  get firstName() {
    return this.signupForm.get('firstName');
  }
  get lastName() {
    return this.signupForm.get('lastName');
  }
  get confirmPassword() {
    return this.signupForm.get('confirmPassword');
  }

}
