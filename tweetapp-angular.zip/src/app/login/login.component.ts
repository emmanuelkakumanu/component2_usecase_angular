import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { UserAuthService } from '../services/user-auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  isLoginValid = false;
  authSource: string;
  error: string;
  username: any;
  password: any;
  status: boolean;
  loginForm: FormGroup = this.fb.group({
    username: ['', [Validators.required, Validators.minLength(4),
    Validators.maxLength(20), Validators.pattern('^[a-zA-Z0-9]*')]],
    password: ['', Validators.required]
  });

  constructor(
    private userAuthService: UserAuthService,
    private authenticationService: AuthenticationService,
    private router: Router, private fb: FormBuilder,
    private route: ActivatedRoute

  ) { }

  ngOnInit(): void {


  }


  onSubmit(loginForm: any) {
    this.authenticationService.authenticate(loginForm.value.username, loginForm.value.password).subscribe((data) => {
      if (loginForm.value.username == data.userName && loginForm.value.password == data.password) {
        this.userAuthService.loggedIn = true;
        this.status = this.userAuthService.loggedIn;
        this.userAuthService.setToken(data.token);
        this.userAuthService.setUser(data.userName);
        this.userAuthService.setLoginid(data.loginid);
        this.router.navigate(['/homepage']);
      } else {
        this.isLoginValid = true;
      }

    },
      (error) => {
      });


  }

}
